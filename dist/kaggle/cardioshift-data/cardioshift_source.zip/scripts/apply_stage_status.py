"""Compatibility entry point that rebuilds and verifies canonical gate status."""

from __future__ import annotations

import json
try:
    from scripts.build_canonical_results import OUTPUT_PATH, main as build_canonical
    from scripts.gate_status import build_gate_status
except ModuleNotFoundError:
    from build_canonical_results import OUTPUT_PATH, main as build_canonical
    from gate_status import build_gate_status


def main() -> None:
    expected = build_gate_status(write=True)
    build_canonical()
    results = json.loads(OUTPUT_PATH.read_text(encoding="utf-8"))
    expected_status = {
        gate: record["status"] for gate, record in expected["gates"].items()
    }
    if results["gate_status"] != expected_status:
        raise RuntimeError("canonical gate status differs from evidence-driven status")
    print(json.dumps(expected_status, indent=2))


if __name__ == "__main__":
    main()

