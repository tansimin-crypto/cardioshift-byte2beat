"""Build honest submission-readiness evidence, checklist, and handoff bundle."""

from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.build_canonical_results import main as build_canonical
from scripts.gate_status import build_gate_status
from scripts.verify_kaggle_rules_evidence import rules_evidence_verified

READINESS_PATH = ROOT / "evidence" / "judge" / "submission_readiness.json"
CHECKLIST_PATH = ROOT / "SUBMISSION_CHECKLIST.md"
DIST_DIR = ROOT / "dist" / "submission"
RULES_EVIDENCE_PATH = ROOT / "evidence" / "kaggle" / "current_rules.json"

RULES_RECONFIRM_STEP = (
    "Reconfirm current Kaggle Rules immediately before the irreversible "
    "final Submit action"
)
MANUAL_STEPS = [
    "Upload the CardioShift Kaggle Dataset",
    "Run All on the public Kaggle Notebook with Internet disabled",
    "Set the Kaggle Notebook to public",
    "Deploy the Demo publicly",
    "Verify Notebook and Demo access while logged out",
    "Demonstrate a real Coder workspace",
    "Select the correct Kaggle Writeup Track",
    RULES_RECONFIRM_STEP,
    "Click the final Kaggle Submit action",
]




def canonical_sha256(path: Path) -> str:
    content = path.read_bytes()
    if path.name == "Dockerfile" or path.suffix.lower() in {
        ".json",
        ".csv",
        ".md",
        ".py",
        ".yaml",
        ".yml",
        ".tf",
        ".sh",
        ".ipynb",
    }:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return hashlib.sha256(content).hexdigest()


def copy_file(relative: str) -> None:
    source = ROOT / relative
    if not source.exists():
        raise FileNotFoundError(source)
    target = DIST_DIR / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def main() -> None:
    gate_report = build_gate_status(write=True)
    build_canonical()
    current_rules_verified = rules_evidence_verified(RULES_EVIDENCE_PATH)
    rules_capture_step = None
    if current_rules_verified:
        rules_evidence = json.loads(
            RULES_EVIDENCE_PATH.read_text(encoding="utf-8")
        )
        rules_capture_step = (
            "Captured and reviewed Kaggle Rules at "
            f"{rules_evidence['captured_at_utc']} via official CLI"
        )
    completed_release_steps = [rules_capture_step] if rules_capture_step else []
    manual_release_steps = (
        MANUAL_STEPS
        if current_rules_verified
        else ["Capture and review current Kaggle Rules", *MANUAL_STEPS]
    )
    coder_runtime_passed = (
        gate_report["gates"].get("G5_coder", {}).get("status") == "pass"
    )
    if coder_runtime_passed:
        completed_release_steps.append(
            "Demonstrated a real Coder workspace with restart verification"
        )
        manual_release_steps = [
            step
            for step in manual_release_steps
            if step != "Demonstrate a real Coder workspace"
        ]
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        text=True,
    ).strip()
    branch = subprocess.check_output(
        ["git", "branch", "--show-current"],
        cwd=ROOT,
        text=True,
    ).strip()
    gates: dict[str, Any] = {}
    for name, record in gate_report["gates"].items():
        gates[name] = {
            "status": record["status"],
            "supporting_artifact": record["evidence_path"],
            "sha256": record["evidence_sha256"],
            "command": record["command"],
            "unresolved_blockers": record["unresolved_blockers"],
        }
    statuses = [record["status"] for record in gates.values()]
    locally_complete = all(
        status == "pass"
        for name, status in (
            (name, record["status"])
            for name, record in gates.items()
            if name not in {"G5_coder", "G6_public_links"}
        )
    )
    report = {
        "schema_version": "1.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "branch": branch,
        "head": head,
        "status": (
            "blocked_manual_release_steps"
            if any(status != "pass" for status in statuses)
            else "all_machine_and_public_gates_pass"
        ),
        "submission_ready_claimed": False,
        "local_machine_gates_complete": locally_complete,
        "gates": gates,
        "completed_release_steps": completed_release_steps,
        "manual_release_steps": manual_release_steps,
        "rules_evidence": (
            str(RULES_EVIDENCE_PATH.relative_to(ROOT)).replace("\\", "/")
            if current_rules_verified
            else None
        ),
        "prohibited_automatic_actions": [
            "make repository public",
            "publish Kaggle Dataset or Notebook",
            "deploy Demo",
            "create real Coder workspace",
            "submit Kaggle Writeup",
        ],
    }
    READINESS_PATH.parent.mkdir(parents=True, exist_ok=True)
    READINESS_PATH.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    checklist = [
        "# Submission checklist",
        "",
        f"- Branch: `{branch}`",
        f"- Evidence HEAD: `{head}`",
        f"- Overall state: **{report['status']}**",
        "- “Submission ready” is not claimed while any public/runtime gate is open.",
        "",
        "## Machine gates",
        "",
    ]
    for name, record in gates.items():
        mark = "x" if record["status"] == "pass" else " "
        checklist.append(f"- [{mark}] `{name}` — `{record['status']}`")
        checklist[-1] = f"- [{mark}] `{name}` - `{record['status']}`"
        for blocker in record["unresolved_blockers"]:
            checklist.append(f"  - Blocker: {blocker}")
    checklist.extend(["", "## Completed release checks", ""])
    checklist.extend(f"- [x] {step}" for step in completed_release_steps)
    checklist.extend(["", "## Manual release steps", ""])
    checklist.extend(f"- [ ] {step}" for step in manual_release_steps)
    checklist.extend(
        [
            "",
            "## Safety statement",
            "",
            "CardioShift is a retrospective research benchmark. It is not for "
            "diagnosis, treatment, medication, triage, or real-patient decisions.",
            "",
        ]
    )
    CHECKLIST_PATH.write_text("\n".join(checklist), encoding="utf-8")

    if DIST_DIR.exists():
        shutil.rmtree(DIST_DIR)
    for relative in (
        "README.md",
        "SUBMISSION_CHECKLIST.md",
        "app.py",
        "requirements.lock",
        "requirements-notebook.lock",
        "requirements-demo.lock",
        "notebooks/CardioShift_Research_Report.ipynb",
        "report/manuscript.md",
        "outputs/results.json",
        "outputs/metrics/robustness_results.json",
        "evidence/frozen_e1_e5.json",
        "evidence/gates/status.json",
        "evidence/g3/verification.json",
        "evidence/g3/notebook_execution.json",
        "evidence/g4/full_clean_reproduction.json",
        "evidence/g5/verification.json",
        "evidence/g5/runtime_verification.json",
        "evidence/judge/submission_readiness.json",
        "evidence/kaggle/current_rules.json",
        "evidence/kaggle/raw_pages.json",
        "coder/main.tf",
        "coder/Dockerfile",
        "coder/startup.sh",
        "coder/README_CODER.md",
        "coder/known_hosts",
    ):
        copy_file(relative)
    manifest = {
        str(path.relative_to(DIST_DIR)).replace("\\", "/"): {
            "bytes": path.stat().st_size,
            "sha256": canonical_sha256(path),
        }
        for path in sorted(DIST_DIR.rglob("*"))
        if path.is_file()
    }
    (DIST_DIR / "MANIFEST.json").write_text(
        json.dumps(
            {
                "schema_version": "1.0",
                "submission_ready_claimed": False,
                "files": manifest,
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "readiness": str(READINESS_PATH),
                "checklist": str(CHECKLIST_PATH),
                "dist_files": len(manifest),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
