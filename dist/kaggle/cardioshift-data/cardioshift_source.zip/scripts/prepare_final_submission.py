"""Assemble local, upload-ready Kaggle submission materials without publishing."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dist" / "final-submission"
KAGGLE_USER = "simingtan"
DATASET_SLUG = "cardioshift-byte2beat-offline"
KERNEL_SLUG = "cardioshift-know-when-not-to-predict"
CODER_RUNTIME = ROOT / "evidence" / "g5" / "runtime_verification.json"
TEXT_SUFFIXES = {
    ".cff", ".csv", ".hcl", ".ipynb", ".json", ".lock", ".md", ".py",
    ".sh", ".tf", ".txt", ".yaml", ".yml",
}


def canonical_bytes(path: Path) -> bytes:
    content = path.read_bytes()
    if path.suffix.lower() in TEXT_SUFFIXES or path.name in {
        "Dockerfile", "LICENSE", "known_hosts",
    }:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return content


def sha256(path: Path) -> str:
    return hashlib.sha256(canonical_bytes(path)).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def copy_file(source: Path, target: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def tested_release_sha() -> str:
    runtime = json.loads(CODER_RUNTIME.read_text(encoding="utf-8"))
    sha = runtime.get("tested_release_sha", "")
    if runtime.get("status") != "pass" or len(sha) != 40:
        raise RuntimeError("valid Coder runtime evidence is required")
    return sha


def main() -> None:
    tested_sha = tested_release_sha()
    public_release = ROOT / "dist" / "public-release"
    kaggle_dataset = ROOT / "dist" / "kaggle" / "cardioshift-data"
    notebook = ROOT / "notebooks" / "CardioShift_Research_Report.ipynb"
    for required in (
        public_release / "MANIFEST.json",
        public_release / "KAGGLE_WRITEUP.md",
        public_release / "CODER_DEMO.md",
        kaggle_dataset / "manifest.json",
        notebook,
    ):
        if not required.is_file():
            raise FileNotFoundError(required)

    if OUTPUT.exists():
        shutil.rmtree(OUTPUT)
    OUTPUT.mkdir(parents=True)

    dataset_dir = OUTPUT / "01-kaggle-dataset"
    shutil.copytree(kaggle_dataset, dataset_dir)
    write_json(
        dataset_dir / "dataset-metadata.json",
        {
            "title": "CardioShift Offline Reproducibility Data",
            "id": f"{KAGGLE_USER}/{DATASET_SLUG}",
            "licenses": [{"name": "CC-BY-4.0"}],
            "subtitle": (
                "Four-hospital UCI data, frozen results, predictions, "
                "checksums, and source."
            ),
        },
    )

    notebook_dir = OUTPUT / "02-kaggle-notebook"
    copy_file(notebook, notebook_dir / notebook.name)
    write_json(
        notebook_dir / "kernel-metadata.json",
        {
            "id": f"{KAGGLE_USER}/{KERNEL_SLUG}",
            "title": "CardioShift: Know When Not to Predict",
            "code_file": notebook.name,
            "language": "python",
            "kernel_type": "notebook",
            "is_private": "false",
            "enable_gpu": "false",
            "enable_tpu": "false",
            "enable_internet": "false",
            "machine_shape": "",
            "dataset_sources": [f"{KAGGLE_USER}/{DATASET_SLUG}"],
            "competition_sources": ["byte-2-beat"],
            "kernel_sources": [],
            "model_sources": [],
        },
    )

    writeup_dir = OUTPUT / "03-writeup-and-demo"
    for name in ("KAGGLE_WRITEUP.md", "DEMO_SCRIPT.md", "CODER_DEMO.md"):
        copy_file(public_release / name, writeup_dir / name)
    copy_file(ROOT / "report" / "manuscript.md", writeup_dir / "manuscript.md")
    ledger_fields = (
        "criterion", "weight", "claim", "visible_proof", "source_artifact",
        "evidence_type", "allowed_wording", "required_limitations", "status",
    )
    ledger_rows = [
        {
            "criterion": "Usefulness", "weight": 15,
            "claim": "Random splitting overstates transfer to an unseen hospital.",
            "visible_proof": "0.892 random-split AUROC versus 0.789 pooled LOHO AUROC.",
            "source_artifact": "outputs/results.json:key_findings",
            "evidence_type": "frozen retrospective external validation",
            "allowed_wording": "measured optimism gap under this four-hospital benchmark",
            "required_limitations": "not a deployment or clinical-impact study",
            "status": "verified",
        },
        {
            "criterion": "Informativeness", "weight": 15,
            "claim": "Hospital shift and deferral costs are quantified with uncertainty.",
            "visible_proof": "n=920; LOHO CI 0.758-0.818; 40.5% coverage; 10.2% accepted-case error.",
            "source_artifact": "outputs/results.json and patient-level predictions",
            "evidence_type": "frozen metrics and bootstrap intervals",
            "allowed_wording": "coverage-error tradeoff",
            "required_limitations": "deferral is not proof of clinical safety",
            "status": "verified",
        },
        {
            "criterion": "Documentation Quality", "weight": 15,
            "claim": "The report runs offline from attached data and a locked environment.",
            "visible_proof": "Notebook Run All locally passed with Internet disabled; manifests and hashes included.",
            "source_artifact": "notebooks/CardioShift_Research_Report.ipynb; manifest.json",
            "evidence_type": "executed offline replay and content hashes",
            "allowed_wording": "locally verified; Kaggle public Run All still required",
            "required_limitations": "do not call local execution a public Kaggle run",
            "status": "verified_local_pending_kaggle",
        },
        {
            "criterion": "Novelty", "weight": 15,
            "claim": "The project audits when confidence should not transfer, including gate misses.",
            "visible_proof": "Accepted correct, deferred error, and confident uncaught error cases.",
            "source_artifact": "DEMO_SCRIPT.md; outputs/predictions/safety_loho_predictions.csv",
            "evidence_type": "fixed deidentified retrospective cases",
            "allowed_wording": "failure-mode benchmark for knowing when not to predict",
            "required_limitations": "no causal or patient-use claim",
            "status": "verified",
        },
        {
            "criterion": "Coder integration", "weight": "cash-prize eligibility",
            "claim": "A real Coder workspace ran and restarted the exact audited release.",
            "visible_proof": "tests.ok, services.ok, exact SHA, Jupyter API 200, Streamlit health ok.",
            "source_artifact": "evidence/g5/runtime_verification.json; CODER_DEMO.md",
            "evidence_type": "real local Coder runtime",
            "allowed_wording": "verified Coder workspace integration",
            "required_limitations": "not a public hosted clinical service",
            "status": "verified",
        },
    ]
    with (writeup_dir / "rubric-evidence-ledger.csv").open(
        "w", encoding="utf-8", newline=""
    ) as handle:
        writer = csv.DictWriter(handle, fieldnames=ledger_fields)
        writer.writeheader()
        writer.writerows(ledger_rows)

    project_dir = OUTPUT / "04-public-project" / "cardioshift-public-release"
    shutil.copytree(public_release, project_dir)

    bundles = OUTPUT / "05-upload-bundles"
    bundles.mkdir(parents=True)
    copy_file(ROOT / "dist" / "public-release.zip", bundles / "cardioshift-public-release.zip")
    shutil.make_archive(
        str(bundles / "cardioshift-kaggle-dataset"),
        "zip",
        root_dir=dataset_dir,
    )

    form = f"""# Kaggle submission form draft

## Title

CardioShift: Know When Not to Predict

## Subtitle

A four-hospital external-validation benchmark for dataset shift, calibration,
and selective prediction in retrospective heart-disease data.

## Track

General

## Public Notebook

https://www.kaggle.com/code/simingtan/cardioshift-know-when-not-to-predict

## Public Project Link

https://github.com/tansimin-crypto/cardioshift-byte2beat

## Written report/manuscript

https://github.com/tansimin-crypto/cardioshift-byte2beat/blob/main/report/manuscript.md

## Writeup body

Paste `03-writeup-and-demo/KAGGLE_WRITEUP.md`; its three public URLs are
locked to the logged-out-verified release locations.

## Immutable evidence

- Runtime-tested product SHA: `{tested_sha}`
- Coder evidence: `03-writeup-and-demo/CODER_DEMO.md`
- Notebook Internet: disabled
- Dataset license: CC BY 4.0, DOI 10.24432/C52P4X
"""
    (OUTPUT / "SUBMISSION_FORM.md").write_text(form, encoding="utf-8", newline="\n")

    checklist = """# Final release checklist

## Locally prepared

- [x] Kaggle Dataset directory and metadata
- [x] Kaggle Notebook directory and metadata
- [x] Internet disabled in kernel metadata
- [x] Writeup, manuscript, Coder demo, and judge demo script
- [x] Sanitized standalone public-repository tree
- [x] Upload ZIP bundles and SHA-256 manifest

## Requires explicit authorization / external verification

- [ ] Create the private Kaggle Dataset and upload `01-kaggle-dataset`
- [ ] Push `02-kaggle-notebook` privately and wait for Run All success
- [ ] Compare Kaggle outputs and source with the audited local artifacts
- [ ] Make the Notebook public and verify it while logged out
- [ ] Create a separate public GitHub repository from `04-public-project`
- [ ] Verify the public repository while logged out
- [ ] Insert the verified URLs into the Writeup
- [ ] Run the final cross-surface claims review
- [ ] Select Track `General`
- [ ] Recapture current Kaggle Rules immediately before Submit
- [ ] Click final Submit only after explicit authorization
"""
    (OUTPUT / "FINAL_CHECKLIST.md").write_text(
        checklist, encoding="utf-8", newline="\n"
    )

    files = {
        path.relative_to(OUTPUT).as_posix(): {
            "bytes": len(canonical_bytes(path)),
            "sha256": sha256(path),
        }
        for path in sorted(OUTPUT.rglob("*"))
        if path.is_file() and path.name != "SHA256SUMS.json"
    }
    write_json(
        OUTPUT / "SHA256SUMS.json",
        {
            "schema_version": "1.0",
            "published": False,
            "canonical_text_newlines": "LF",
            "tested_release_sha": tested_sha,
            "files": files,
        },
    )
    print(
        json.dumps(
            {
                "status": "prepared_not_published",
                "output": str(OUTPUT),
                "files": len(files),
                "dataset_id": f"{KAGGLE_USER}/{DATASET_SLUG}",
                "kernel_id": f"{KAGGLE_USER}/{KERNEL_SLUG}",
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
