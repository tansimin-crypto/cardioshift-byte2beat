"""Build evidence-driven gate status records for canonical results."""

from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUTPUT_PATH = ROOT / "evidence" / "gates" / "status.json"
FROZEN_PATH = ROOT / "evidence" / "frozen_e1_e5.json"


def canonical_content(path: Path, content: bytes) -> bytes:
    if path.name == "Dockerfile" or path.suffix.lower() in {".json", ".csv", ".md", ".py", ".yaml", ".yml", ".tf", ".sh", ".ipynb"}:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return content


def sha256(path: Path) -> str:
    return hashlib.sha256(canonical_content(path, path.read_bytes())).hexdigest()


def git_blob_sha256(revision: str, relative: str) -> str | None:
    completed = subprocess.run(
        ["git", "show", f"{revision}:{relative}"],
        cwd=ROOT,
        capture_output=True,
    )
    if completed.returncode != 0:
        return None
    return hashlib.sha256(
        canonical_content(ROOT / relative, completed.stdout)
    ).hexdigest()


def checkout_matches(path: Path, expected: str) -> bool:
    return sha256(path) == expected


def frozen_artifact_valid(
    manifest: dict[str, Any] | None,
    relative: str,
) -> bool:
    if manifest is None or relative not in manifest.get("artifacts", {}):
        return False
    expected = manifest["artifacts"][relative]["sha256"]
    accepted = manifest.get("accepted_commit")
    return bool(
        accepted
        and expected == git_blob_sha256(accepted, relative)
        and expected == git_blob_sha256("HEAD", relative)
        and checkout_matches(ROOT / relative, expected)
    )


def artifact_claims_valid(
    payload: dict[str, Any] | None,
    claims: dict[str, Path],
) -> bool:
    if payload is None:
        return False
    recorded = payload.get("artifact_hashes", {})
    return all(
        path.exists() and recorded.get(name) == sha256(path)
        for name, path in claims.items()
    )


def semantic_results_sha256(path: Path) -> str:
    payload = json.loads(path.read_text(encoding="utf-8"))
    for key in (
        "generated_at_utc",
        "code_commit_before_canonicalization",
        "gate_status_schema_version",
        "gate_status",
        "gate_evidence",
        "independent_judge",
        "g4_local_environment_check",
        "artifact_hashes",
    ):
        payload.pop(key, None)
    content = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(content).hexdigest()




def load_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def git_head() -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        text=True,
    ).strip()


def evidence_record(
    *,
    status: str,
    evidence_path: Path | None,
    command: str,
    blockers: list[str],
    verified_at: str | None = None,
) -> dict[str, Any]:
    relative = (
        str(evidence_path.relative_to(ROOT)).replace("\\", "/")
        if evidence_path is not None and evidence_path.exists()
        else None
    )
    return {
        "status": status,
        "evidence_path": relative,
        "evidence_sha256": (
            sha256(evidence_path)
            if evidence_path is not None and evidence_path.exists()
            else None
        ),
        "verified_at": verified_at,
        "command": command,
        "unresolved_blockers": blockers,
    }


def evidence_time(payload: dict[str, Any] | None) -> str | None:
    if payload is None:
        return None
    return (
        payload.get("verified_at_utc")
        or payload.get("generated_at_utc")
        or payload.get("captured_at_utc")
    )


def build_gate_status(*, write: bool = True) -> dict[str, Any]:
    g1_path = ROOT / "data" / "gate_g1_verification.json"
    g2_path = ROOT / "evidence" / "g2" / "verification.json"
    e3e5_path = ROOT / "evidence" / "e3_e5" / "verification.json"
    e6e7_path = ROOT / "evidence" / "e6_e7" / "verification.json"
    judge_path = ROOT / "evidence" / "judge" / "current_verdict.json"
    g3_path = ROOT / "evidence" / "g3" / "verification.json"
    g3_execution_path = ROOT / "evidence" / "g3" / "notebook_execution.json"
    g4_local_path = ROOT / "evidence" / "g4" / "local_clean_environment.json"
    g4_full_path = ROOT / "evidence" / "g4" / "full_clean_reproduction.json"
    g5_path = ROOT / "evidence" / "g5" / "verification.json"
    g6_path = ROOT / "evidence" / "g6" / "public_access.json"

    g1 = load_json(g1_path)
    g2 = load_json(g2_path)
    e3e5 = load_json(e3e5_path)
    e6e7 = load_json(e6e7_path)
    judge = load_json(judge_path)
    g3 = load_json(g3_path)
    g4_local = load_json(g4_local_path)
    g4_full = load_json(g4_full_path)
    g5 = load_json(g5_path)
    g6 = load_json(g6_path)
    frozen = load_json(FROZEN_PATH)

    notebook_exists = (
        ROOT / "notebooks" / "CardioShift_Research_Report.ipynb"
    ).exists()
    app_exists = (ROOT / "app.py").exists()
    coder_files = [
        ROOT / "coder" / "main.tf",
        ROOT / "coder" / "Dockerfile",
        ROOT / "coder" / "startup.sh",
        ROOT / "coder" / "README_CODER.md",
    ]
    g1_valid = bool(
        g1
        and g1.get("status") == "pass"
        and g1.get("gate") == "G1"
        and g1.get("rows") == 920
        and g1.get("cohort_sha256")
    )
    g2_valid = bool(
        g2
        and g2.get("status") == "pass"
        and frozen_artifact_valid(frozen, "evidence/g2/verification.json")
        and frozen_artifact_valid(frozen, "outputs/metrics/results.json")
        and frozen_artifact_valid(frozen, "outputs/predictions/loho_predictions.csv")
        and frozen_artifact_valid(frozen, "outputs/predictions/random_split_predictions.csv")
        and frozen_artifact_valid(frozen, "outputs/audit/loho_training_ledgers.json")
    )
    e3e5_valid = bool(
        e3e5
        and e3e5.get("status") == "pass"
        and frozen_artifact_valid(frozen, "evidence/e3_e5/verification.json")
        and frozen_artifact_valid(frozen, "outputs/metrics/shift_safety_results.json")
        and frozen_artifact_valid(frozen, "outputs/predictions/safety_loho_predictions.csv")
        and frozen_artifact_valid(frozen, "outputs/predictions/loho_predictions.csv")
    )
    e6e7_valid = bool(
        e6e7
        and e6e7.get("status") == "pass"
        and e6e7.get("schema_version") == "1.0"
        and artifact_claims_valid(
            e6e7,
            {
                "robustness_results": ROOT / "outputs" / "metrics" / "robustness_results.json",
                "robustness_predictions": ROOT / "outputs" / "predictions" / "robustness_predictions.csv",
            },
        )
    )
    g3_valid = bool(
        g3
        and g3.get("status") == "pass"
        and g3.get("schema_version") == "1.0"
        and g3.get("checks", {}).get("numeric_consistency") is True
        and artifact_claims_valid(
            g3,
            {
                "notebook": ROOT / "notebooks" / "CardioShift_Research_Report.ipynb",
                "app": ROOT / "app.py",
                "README.md": ROOT / "README.md",
                "report/manuscript.md": ROOT / "report" / "manuscript.md",
                "src/results_access.py": ROOT / "src" / "results_access.py",
            },
        )
        and (ROOT / "outputs" / "results.json").exists()
        and g3.get("results_semantic_sha256")
        == semantic_results_sha256(ROOT / "outputs" / "results.json")
        and g3.get("notebook_execution_evidence")
        == sha256(g3_execution_path)
    )
    g4_valid = bool(
        g4_full
        and g4_full.get("status") == "pass"
        and g4_full.get("schema_version") == "1.0"
        and g4_full.get("temporary_workspace") is True
        and g4_full.get("artifact_comparisons_passed") is True
        and g4_full.get("verified_head")
        and subprocess.run(
            ["git", "merge-base", "--is-ancestor", g4_full["verified_head"], "HEAD"],
            cwd=ROOT,
            capture_output=True,
        ).returncode
        == 0
        and bool(g4_full.get("commands"))
        and all(item.get("returncode") == 0 for item in g4_full.get("commands", []))
        and bool(g4_full.get("artifact_comparisons"))
        and all(
            item.get("pass") is True
            for item in g4_full.get("artifact_comparisons", {}).values()
        )
        and bool(g4_full.get("source_hashes"))
        and all(
            (ROOT / relative).exists()
            and sha256(ROOT / relative) == expected
            for relative, expected in g4_full.get("source_hashes", {}).items()
        )
    )
    g5_valid = bool(
        g5
        and g5.get("schema_version") == "1.0"
        and g5.get("status")
        in {"implementation_complete_runtime_verification_pending", "pass"}
        and all(g5.get("static_checks", {}).values())
        and (g5.get("runtime_verified") is False or not g5.get("unresolved_blockers"))
        and (g5.get("status") != "pass" or g5.get("runtime_verified") is True)
        and artifact_claims_valid(
            g5,
            {
                str(path.relative_to(ROOT)).replace("\\", "/"): path
                for path in coder_files
            },
        )
    )
    g6_valid = bool(
        g6
        and g6.get("status") == "pass"
        and g6.get("logged_out_verified") is True
        and all(
            str(g6.get("urls", {}).get(name, "")).startswith("http")
            for name in ("notebook", "demo")
        )
        and all(
            g6.get("probes", {}).get(name, {}).get("url")
            == g6.get("urls", {}).get(name)
            and g6.get("probes", {}).get(name, {}).get("status_code") == 200
            and g6.get("probes", {}).get(name, {}).get("logged_out") is True
            and bool(g6.get("probes", {}).get(name, {}).get("verified_at_utc"))
            for name in ("notebook", "demo")
        )
        and not g6.get("unresolved_blockers")
    )

    g3_pass = notebook_exists and app_exists and g3_valid
    g4_pass = g4_valid
    coder_implemented = all(path.exists() for path in coder_files)

    gates = {
        "G1_data_contract": evidence_record(
            status="pass" if g1_valid else "fail",
            evidence_path=g1_path,
            command="python scripts/verify_gate_g1.py",
            blockers=[] if g1_valid else ["G1 evidence schema or verifier status is invalid"],
            verified_at=evidence_time(g1),
        ),
        "G2_hospital_holdout": evidence_record(
            status="pass" if g2_valid else "fail",
            evidence_path=g2_path,
            command="python scripts/verify_gate_g2.py",
            blockers=[] if g2_valid else ["G2 evidence is not bound to accepted Git blobs"],
            verified_at=evidence_time(g2),
        ),
        "E3_E5_shift_safety": evidence_record(
            status="pass" if e3e5_valid else "fail",
            evidence_path=e3e5_path,
            command="python scripts/verify_shift_safety.py",
            blockers=(
                []
                if e3e5_valid
                else ["E3/E5 verifier fails"]
            ),
            verified_at=evidence_time(e3e5),
        ),
        "E6_E7_robustness_runtime": evidence_record(
            status=(
                "pass"
                if e6e7_valid
                else "pending"
            ),
            evidence_path=e6e7_path,
            command="python scripts/verify_robustness.py",
            blockers=(
                []
                if e6e7_valid
                else ["E6/E7 artifacts and verification are incomplete"]
            ),
            verified_at=evidence_time(e6e7),
        ),
        "G3_single_source": evidence_record(
            status="pass" if g3_pass else "partial_missing_notebook_and_app",
            evidence_path=g3_path,
            command="python scripts/verify_gate_g3.py",
            blockers=(
                []
                if g3_pass
                else [
                    *([] if notebook_exists else ["Notebook is missing"]),
                    *([] if app_exists else ["App is missing"]),
                    "Cross-surface numeric consistency is not verified",
                ]
            ),
            verified_at=evidence_time(g3),
        ),
        "G4_clean_environment": evidence_record(
            status="pass" if g4_pass else "pending",
            evidence_path=g4_full_path if g4_pass else g4_local_path,
            command="python scripts/reproduce_all.py",
            blockers=(
                []
                if g4_pass
                else [
                    "Raw-to-results temporary-directory reproduction is incomplete",
                    "Kaggle public Notebook Run All is unverified",
                ]
            ),
            verified_at=evidence_time(g4_full if g4_pass else g4_local),
        ),
        "G5_coder": evidence_record(
            status=(
                (
                    "pass"
                    if g5.get("runtime_verified") is True
                    else "implementation_complete_runtime_verification_pending"
                )
                if coder_implemented and g5_valid
                else "fail_missing_coder"
            ),
            evidence_path=g5_path,
            command="python -m unittest tests.test_coder_contract -v",
            blockers=(
                g5.get("unresolved_blockers", [])
                if coder_implemented and g5_valid
                else ["Coder Terraform, Docker, startup, and evidence are missing"]
            ),
            verified_at=evidence_time(g5),
        ),
        "G6_public_links": evidence_record(
            status=(
                "pass"
                if g6_valid
                else "fail_missing_public_links"
            ),
            evidence_path=g6_path,
            command="manual logged-out access verification",
            blockers=(
                []
                if g6_valid
                else [
                    "Public Notebook is not verified",
                    "Public Demo or project link is not verified",
                    "Logged-out access is not verified",
                ]
            ),
            verified_at=evidence_time(g6),
        ),
        "G7_claims": evidence_record(
            status=(
                judge["gates"]["G7"]
                if judge is not None
                else "pending_independent_review"
            ),
            evidence_path=judge_path,
            command="independent judge medical-claims scan",
            blockers=(
                []
                if judge is not None and judge.get("gates", {}).get("G7") == "pass"
                else (
                    ["Final Notebook, App, and Kaggle Writeup require a new claims review"]
                    if judge is not None
                    else ["Independent claims review is missing"]
                )
            ),
            verified_at=evidence_time(judge),
        ),
    }
    result = {
        "schema_version": "2.0",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "generated_from_head": git_head(),
        "gates": gates,
    }
    if write:
        OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
        OUTPUT_PATH.write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    return result


if __name__ == "__main__":
    print(json.dumps(build_gate_status(write=True), indent=2))

