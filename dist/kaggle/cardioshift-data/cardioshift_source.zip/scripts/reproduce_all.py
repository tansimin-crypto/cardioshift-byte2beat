"""Run raw-to-results reproduction in a fresh local clone and isolated venvs."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "evidence" / "g4" / "full_clean_reproduction.json"


def canonical_sha256(path: Path) -> str:
    content = path.read_bytes()
    if path.name == "Dockerfile" or path.suffix.lower() in {
        ".json",
        ".csv",
        ".md",
        ".py",
        ".yaml",
        ".yml",
        ".tf",
        ".sh",
    }:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return hashlib.sha256(content).hexdigest()


def run(
    command: list[str],
    *,
    cwd: Path,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    effective_env = os.environ.copy() if env is None else env.copy()
    if (cwd / "src").exists():
        existing = effective_env.get("PYTHONPATH")
        effective_env["PYTHONPATH"] = (
            str(cwd)
            if not existing
            else str(cwd) + os.pathsep + existing
        )
    print("$", " ".join(command), flush=True)
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=effective_env,
        text=True,
        capture_output=True,
    )
    record = {
        "command": command,
        "returncode": completed.returncode,
        "stdout_tail": completed.stdout[-5000:],
        "stderr_tail": completed.stderr[-5000:],
    }
    if completed.returncode != 0:
        print(json.dumps(record, indent=2), flush=True)
        raise RuntimeError(f"command failed: {' '.join(command)}")
    return record


def main() -> None:
    verified_head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        text=True,
    ).strip()
    source_paths = (
        "requirements.lock",
        "requirements-notebook.lock",
        "requirements-demo.lock",
        "configs/experiment.yaml",
        "scripts/build_cohort.py",
        "scripts/run_core_experiments.py",
        "scripts/run_shift_safety.py",
        "scripts/verify_gate_g1.py",
        "scripts/verify_gate_g2.py",
        "scripts/run_robustness.py",
        "scripts/build_canonical_results.py",
        "scripts/verify_shift_safety.py",
        "scripts/build_kaggle_notebook.py",
        "scripts/execute_notebook.py",
        "scripts/verify_robustness.py",
        "scripts/make_core_figures.py",
        "scripts/compare_reproduction.py",
        "app.py",
        "scripts/verify_gate_g3.py",
        "scripts/gate_status.py",
        "scripts/render_scientific_docs.py",
        "scripts/verify_frozen_checkout.py",
    )
    source_hashes = {
        relative: canonical_sha256(ROOT / relative) for relative in source_paths
    }
    commands: list[dict[str, Any]] = []
    comparison: dict[str, Any]
    notebook_summary: dict[str, Any]

    with tempfile.TemporaryDirectory(prefix="cardioshift-reproduction-") as raw_tmp:
        temp_parent = Path(raw_tmp)
        clone = temp_parent / "repo"
        commands.append(
            run(
                ["git", "clone", "--no-hardlinks", "--quiet", str(ROOT), str(clone)],
                cwd=temp_parent,
            )
        )
        commands.append(run(["git", "checkout", "--detach", verified_head], cwd=clone))
        commands.append(run([sys.executable, "scripts/verify_frozen_checkout.py"], cwd=clone))

        outputs = clone / "outputs"
        if outputs.exists():
            shutil.rmtree(outputs)
        processed = clone / "data" / "processed"
        if processed.exists():
            shutil.rmtree(processed)
        raw_dir = clone / "data" / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        for source in (
            clone / "dist" / "kaggle" / "cardioshift-data" / "raw"
        ).glob("*.data"):
            content = source.read_bytes().replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
            (raw_dir / source.name).write_bytes(content)

        core_venv = temp_parent / "venv-core"
        demo_venv = temp_parent / "venv-demo"
        commands.append(run([sys.executable, "-m", "venv", str(core_venv)], cwd=clone))
        commands.append(run([sys.executable, "-m", "venv", str(demo_venv)], cwd=clone))
        core_python = (
            core_venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        )
        demo_python = (
            demo_venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        )
        commands.append(
            run(
                [
                    str(core_python),
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    "requirements.lock",
                    "-r",
                    "requirements-notebook.lock",
                ],
                cwd=clone,
            )
        )
        commands.append(
            run(
                [
                    str(demo_python),
                    "-m",
                    "pip",
                    "install",
                    "-r",
                    "requirements-demo.lock",
                ],
                cwd=clone,
            )
        )

        commands.append(
            run(
                [
                    str(core_python),
                    "-m",
                    "compileall",
                    "-q",
                    "scripts",
                    "src",
                    "tests",
                ],
                cwd=clone,
            )
        )
        for script in (
            "scripts/build_cohort.py",
            "scripts/verify_gate_g1.py",
            "scripts/run_core_experiments.py",
            "scripts/verify_gate_g2.py",
            "scripts/run_shift_safety.py",
            "scripts/verify_shift_safety.py",
            "scripts/run_robustness.py",
            "scripts/verify_robustness.py",
            "scripts/make_core_figures.py",
            "scripts/build_canonical_results.py",
            "scripts/render_scientific_docs.py",
            "scripts/build_kaggle_notebook.py",
        ):
            command = [str(core_python), script]
            if script in {
                "scripts/verify_gate_g1.py",
                "scripts/verify_gate_g2.py",
                "scripts/verify_shift_safety.py",
            }:
                command.append("--no-write")
            if script == "scripts/verify_robustness.py":
                command.append("--regenerated-inputs")
            commands.append(run(command, cwd=clone))

        executed = clone / "notebooks" / "CardioShift_Research_Report.executed.ipynb"
        commands.append(
            run(
                [
                    str(core_python),
                    "scripts/execute_notebook.py",
                    "--data-dir",
                    str(clone),
                    "--output",
                    str(executed),
                ],
                cwd=clone,
            )
        )
        for script in (
            "scripts/verify_gate_g3.py",
            "scripts/gate_status.py",
            "scripts/build_canonical_results.py",
            "scripts/build_kaggle_notebook.py",
        ):
            commands.append(run([str(core_python), script], cwd=clone))
        notebook_summary_path = (
            executed.parent / ".notebook-work" / "outputs" / "notebook_run_summary.json"
        )
        notebook_summary = json.loads(
            notebook_summary_path.read_text(encoding="utf-8")
        )

        commands.append(
            run(
                [
                    str(core_python),
                    "-m",
                    "pytest",
                    "-q",
                    "--ignore=tests/test_app_contract.py",
                    "--deselect=tests/test_gate_status_evidence.py::"
                    "GateStatusEvidenceTests::test_frozen_e1_e5_hashes_are_unchanged",
                ],
                cwd=clone,
            )
        )
        commands.append(
            run(
                [
                    str(demo_python),
                    "-m",
                    "pytest",
                    "-q",
                    "tests/test_app_contract.py",
                ],
                cwd=clone,
            )
        )

        sys.path.insert(0, str(ROOT))
        from scripts.compare_reproduction import compare

        comparison = compare(ROOT, clone)
        if not comparison["pass"]:
            raise AssertionError(json.dumps(comparison, indent=2))

    public_access = json.loads(
        (ROOT / "evidence" / "g6" / "public_access.json").read_text(encoding="utf-8")
    )
    kaggle_public_run_all_verified = bool(
        public_access.get("kaggle_notebook", {}).get("status") == "complete"
        and public_access.get("kaggle_notebook", {}).get("is_private") is False
    )
    logged_out_verified = public_access.get("logged_out_verified") is True

    report = {
        "schema_version": "1.0",
        "status": "pass",
        "scope": "local clean raw-to-results reproduction",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "verified_head": verified_head,
        "temporary_workspace": True,
        "fresh_core_virtual_environment": True,
        "fresh_demo_virtual_environment": True,
        "commands": commands,
        "artifact_comparisons_passed": comparison["pass"],
        "artifact_comparisons": comparison["artifacts"],
        "notebook_execution": {
            "status": "pass",
            "internet_used": notebook_summary["internet_used"],
            "canonical_results_sha256": notebook_summary[
                "canonical_results_sha256"
            ],
        },
        "source_hashes": source_hashes,
        "kaggle_public_run_all_verified": kaggle_public_run_all_verified,
        "unresolved_release_steps": [] if kaggle_public_run_all_verified and logged_out_verified else [
            name for name, complete in (
                ("Kaggle public Notebook Run All", kaggle_public_run_all_verified),
                ("logged-out public access verification", logged_out_verified),
            ) if not complete
        ],
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps({"status": "pass", "evidence": str(OUTPUT)}, indent=2))


if __name__ == "__main__":
    main()
