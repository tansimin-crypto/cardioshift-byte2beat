"""Verify immutable E1-E5 evidence before any clean-run regeneration."""

from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "evidence" / "frozen_e1_e5.json"


def canonical_content(path: Path, content: bytes) -> bytes:
    if path.suffix.lower() in {".json", ".csv", ".md", ".py", ".yaml", ".yml"}:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return content


def canonical_bytes(path: Path) -> bytes:
    return canonical_content(path, path.read_bytes())


def git_blob(revision: str, relative: str) -> bytes:
    return subprocess.check_output(
        ["git", "show", f"{revision}:{relative}"],
        cwd=ROOT,
    )


def main() -> None:
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    accepted = manifest["accepted_commit"]
    if subprocess.run(
        ["git", "merge-base", "--is-ancestor", accepted, "HEAD"],
        cwd=ROOT,
    ).returncode:
        raise AssertionError("accepted E1-E5 commit is not an ancestor of HEAD")
    for relative, record in manifest["artifacts"].items():
        expected = record["sha256"]
        observed = {
            "accepted_blob": hashlib.sha256(
                canonical_content(ROOT / relative, git_blob(accepted, relative))
            ).hexdigest(),
            "head_blob": hashlib.sha256(
                canonical_content(ROOT / relative, git_blob("HEAD", relative))
            ).hexdigest(),
            "checkout_normalized": hashlib.sha256(
                canonical_bytes(ROOT / relative)
            ).hexdigest(),
        }
        if (
            observed["accepted_blob"] != expected
            or observed["head_blob"] != expected
            or observed["checkout_normalized"] != expected
        ):
            raise AssertionError(f"frozen artifact mismatch: {relative}: {observed}")
    print(
        json.dumps(
            {
                "status": "pass",
                "accepted_commit": accepted,
                "artifact_count": len(manifest["artifacts"]),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
