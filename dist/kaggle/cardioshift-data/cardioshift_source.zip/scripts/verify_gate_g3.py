"""Verify Notebook/App single-source numeric and claims consistency."""

from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.results_access import ResultsAccessor

NOTEBOOK_PATH = ROOT / "notebooks" / "CardioShift_Research_Report.ipynb"
APP_PATH = ROOT / "app.py"
RESULTS_PATH = ROOT / "outputs" / "results.json"
OUTPUT_PATH = ROOT / "evidence" / "g3" / "verification.json"
EXECUTION_PATH = ROOT / "evidence" / "g3" / "notebook_execution.json"


def canonical_sha256(path: Path) -> str:
    content = path.read_bytes()
    if path.suffix.lower() in {
        ".json",
        ".csv",
        ".md",
        ".py",
        ".yaml",
        ".yml",
        ".ipynb",
    }:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return hashlib.sha256(content).hexdigest()


def semantic_results_sha256(path: Path) -> str:
    payload = json.loads(path.read_text(encoding="utf-8"))
    for key in (
        "generated_at_utc",
        "code_commit_before_canonicalization",
        "gate_status_schema_version",
        "gate_status",
        "gate_evidence",
        "independent_judge",
        "g4_local_environment_check",
        "artifact_hashes",
    ):
        payload.pop(key, None)
    content = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(content).hexdigest()


def main() -> None:
    for path in (
        NOTEBOOK_PATH,
        APP_PATH,
        RESULTS_PATH,
        ROOT / "README.md",
        ROOT / "report" / "manuscript.md",
        ROOT / "src" / "results_access.py",
    ):
        if not path.exists() or path.stat().st_size == 0:
            raise FileNotFoundError(path)

    notebook = json.loads(NOTEBOOK_PATH.read_text(encoding="utf-8"))
    source_code_cells = []
    for index, cell in enumerate(notebook["cells"]):
        if cell["cell_type"] == "code":
            source_code_cells.append(cell)
            ast.parse(
                "".join(cell.get("source", [])),
                filename=f"notebook-cell-{index}",
            )
    execution = json.loads(EXECUTION_PATH.read_text(encoding="utf-8"))
    execution_cells = execution.get("code_cells", [])
    cell_evidence_valid = (
        len(execution_cells) == len(source_code_cells)
        and execution.get("code_cell_count") == len(source_code_cells)
        and execution.get("executed_code_cell_count") == len(source_code_cells)
    )
    for source_cell, executed_cell in zip(source_code_cells, execution_cells):
        source = "".join(source_cell.get("source", []))
        cell_evidence_valid = cell_evidence_valid and bool(
            executed_cell.get("id") == source_cell.get("id")
            and executed_cell.get("source_sha256")
            == hashlib.sha256(source.encode("utf-8")).hexdigest()
            and isinstance(executed_cell.get("execution_count"), int)
            and executed_cell.get("execution_count") > 0
            and isinstance(executed_cell.get("output_count"), int)
            and executed_cell.get("error_count") == 0
            and len(executed_cell.get("outputs_sha256", "")) == 64
        )
    if not (
        execution.get("status") == "pass"
        and execution.get("internet_used") is False
        and execution.get("source_notebook_sha256") == canonical_sha256(NOTEBOOK_PATH)
        and execution.get("canonical_results_semantic_sha256")
        == semantic_results_sha256(RESULTS_PATH)
        and cell_evidence_valid
        and execution.get("notebook_run_summary", {}).get("internet_used") is False
        and execution.get("executed_notebook_sha256")
        and not execution.get("unresolved_blockers")
    ):
        raise AssertionError("Notebook execution evidence is missing, stale, or failed")
    notebook_source = "\n".join(
        "".join(cell.get("source", [])) for cell in notebook["cells"]
    )
    notebook_markdown = "\n".join(
        "".join(cell.get("source", []))
        for cell in notebook["cells"]
        if cell["cell_type"] == "markdown"
    )
    app_source = APP_PATH.read_text(encoding="utf-8")
    app_tree = ast.parse(app_source)
    hardcoded_floats = {
        node.value
        for node in ast.walk(app_tree)
        if isinstance(node, ast.Constant) and isinstance(node.value, float)
    }
    headline_literals = (0.892, 0.789, 0.102, 0.405)
    if any(value in hardcoded_floats for value in headline_literals):
        raise AssertionError("App hardcodes a headline metric")
    if any(str(value) in notebook_markdown for value in headline_literals):
        raise AssertionError("Notebook markdown hardcodes a headline metric")
    if "ResultsAccessor" not in notebook_source or "ResultsAccessor" not in app_source:
        raise AssertionError("Notebook and App must share ResultsAccessor")

    accessor = ResultsAccessor(ROOT)
    canonical = json.loads(RESULTS_PATH.read_text(encoding="utf-8"))
    if accessor.findings != canonical["key_findings"]:
        raise AssertionError("shared accessor differs from canonical findings")
    for phrase in (
        "not for diagnosis",
        "treatment",
        "real-patient",
    ):
        if phrase not in app_source.lower() and phrase not in notebook_source.lower():
            raise AssertionError(f"missing medical non-use phrase: {phrase}")

    artifact_paths = {
        "notebook": NOTEBOOK_PATH,
        "app": APP_PATH,
        "README.md": ROOT / "README.md",
        "report/manuscript.md": ROOT / "report" / "manuscript.md",
        "src/results_access.py": ROOT / "src" / "results_access.py",
    }
    report: dict[str, Any] = {
        "schema_version": "1.0",
        "status": "pass",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "verified_head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=ROOT,
            text=True,
        ).strip(),
        "checks": {
            "numeric_consistency": True,
            "shared_results_accessor": True,
            "headline_metrics_not_hardcoded": True,
            "medical_nonuse_language": True,
            "notebook_schema": notebook.get("nbformat") == 4,
            "notebook_code_compiles": True,
            "notebook_executed_offline": True,
        },
        "artifact_hashes": {
            name: canonical_sha256(path) for name, path in artifact_paths.items()
        },
        "results_semantic_sha256": semantic_results_sha256(RESULTS_PATH),
        "notebook_execution_evidence": canonical_sha256(EXECUTION_PATH),
        "unresolved_blockers": [],
    }
    if not all(report["checks"].values()):
        raise AssertionError(report["checks"])
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
