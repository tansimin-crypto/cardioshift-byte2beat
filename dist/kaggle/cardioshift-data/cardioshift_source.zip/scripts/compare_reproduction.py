"""Compare a clean reproduction with accepted artifacts using explicit semantics."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any
import pandas as pd
import numpy as np
import matplotlib.image as mpimg



def canonical_sha256(path: Path) -> str:
    content = path.read_bytes()
    if path.suffix.lower() in {".json", ".csv", ".md", ".py", ".yaml", ".yml"}:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return hashlib.sha256(content).hexdigest()


def semantic_hash(value: Any) -> str:
    content = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(content).hexdigest()


def scrub_volatile(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: scrub_volatile(item)
            for key, item in value.items()
            if key not in {
                "generated_at_utc",
                "code_commit_before_canonicalization",
                "config_sha256",
            }
        }
    if isinstance(value, list):
        return [scrub_volatile(item) for item in value]
    return value


def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def normalize_numbers(value: Any) -> Any:
    if isinstance(value, dict):
        return {key: normalize_numbers(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_numbers(item) for item in value]
    if isinstance(value, float):
        if pd.isna(value):
            return None
        return round(value, 12)
    if hasattr(value, "item"):
        return normalize_numbers(value.item())
    return value


def compare_csv(reference: Path, candidate: Path) -> dict[str, Any]:
    left = pd.read_csv(reference)
    right = pd.read_csv(candidate)
    columns_equal = list(left.columns) == list(right.columns)
    shape_equal = left.shape == right.shape
    details: dict[str, Any] = {}
    passed = columns_equal and shape_equal
    if columns_equal and shape_equal:
        for column in left.columns:
            if pd.api.types.is_float_dtype(left[column]) and pd.api.types.is_float_dtype(
                right[column]
            ):
                left_values = left[column].to_numpy(dtype=float)
                right_values = right[column].to_numpy(dtype=float)
                finite = np.isfinite(left_values) & np.isfinite(right_values)
                max_abs = float(
                    np.max(np.abs(left_values[finite] - right_values[finite]))
                ) if finite.any() else 0.0
                column_pass = bool(
                    np.allclose(
                        left_values,
                        right_values,
                        atol=1e-12,
                        rtol=0.0,
                        equal_nan=True,
                    )
                )
                details[column] = {
                    "comparison": "absolute_tolerance",
                    "atol": 1e-12,
                    "rtol": 0.0,
                    "max_abs_difference": max_abs,
                    "pass": column_pass,
                }
            else:
                equal = left[column].eq(right[column]) | (
                    left[column].isna() & right[column].isna()
                )
                mismatches = int((~equal).sum())
                column_pass = mismatches == 0
                details[column] = {
                    "comparison": "exact_with_nan_equivalence",
                    "mismatches": mismatches,
                    "pass": column_pass,
                }
            passed = passed and column_pass
    return {
        "comparison": "exact_shape_columns_nonfloats; float_atol_1e-12",
        "reference_sha256": canonical_sha256(reference),
        "candidate_sha256": canonical_sha256(candidate),
        "shape_equal": shape_equal,
        "columns_equal": columns_equal,
        "column_checks": details,
        "pass": bool(passed),
    }



def scientific_payload(relative: str, root: Path) -> Any:
    payload = load(root / relative)
    if relative == "outputs/metrics/results.json":
        return {
            key: payload[key]
            for key in (
                "study",
                "E1_repeated_random_split",
                "E2_leave_one_hospital_out",
                "comparison",
            )
        }
    if relative == "outputs/metrics/shift_safety_results.json":
        recorded = payload["reproducibility"]["core_results_sha256"]
        actual = canonical_sha256(root / "outputs/metrics/results.json")
        if recorded != actual:
            raise AssertionError("E3/E5 core-results provenance hash is invalid")
        payload["reproducibility"]["core_results_sha256"] = (
            "validated_against_local_core_results"
        )
        return {
            "status": payload["status"],
            "reproducibility": payload["reproducibility"],
            "E3_shift": payload["E3_shift"],
            "E5_safety": payload["E5_safety"],
        }
    if relative == "outputs/metrics/robustness_results.json":
        recorded = payload["protocol"]["threshold_source_sha256"]
        actual = canonical_sha256(
            root / "outputs/metrics/shift_safety_results.json"
        )
        if recorded != actual:
            raise AssertionError("E6 threshold-source provenance hash is invalid")
        payload["protocol"]["threshold_source_sha256"] = (
            "validated_against_local_shift_safety_results"
        )
        return {
            "status": payload["status"],
            "protocol": payload["protocol"],
            "fold_metadata": payload["fold_metadata"],
            "E6_robustness": payload["E6_robustness"],
            "E7_runtime_contract": {
                key: payload["E7_runtime"][key]
                for key in (
                    "claim_scope",
                    "warmup_repeats",
                    "measurement_repeats",
                    "cold_load_repeats",
                )
            },
        }
    if relative == "outputs/results.json":
        recorded = payload["experiments"]["E3_E5"]["reproducibility"][
            "core_results_sha256"
        ]
        actual = canonical_sha256(root / "outputs/metrics/results.json")
        if recorded != actual:
            raise AssertionError("canonical E3/E5 provenance hash is invalid")
        payload["experiments"]["E3_E5"]["reproducibility"][
            "core_results_sha256"
        ] = "validated_against_local_core_results"
        return scrub_volatile({
            "project": payload["project"],
            "key_findings": payload["key_findings"],
            "data": payload["data"],
            "limitations": payload["limitations"],
            "science": {
                "E1_E2": payload["experiments"]["E1_E2"],
                "E3_E5": payload["experiments"]["E3_E5"],
                "E6_robustness": payload["experiments"]["E6_robustness"],
            },
        })
    raise KeyError(relative)


def compare(reference: Path, candidate: Path) -> dict[str, Any]:
    tabular_semantic = (
        "outputs/predictions/loho_predictions.csv",
        "outputs/predictions/random_split_predictions.csv",
        "outputs/predictions/safety_loho_predictions.csv",
        "outputs/predictions/robustness_predictions.csv",
    )
    json_semantic = ("outputs/audit/loho_training_ledgers.json",)
    semantic = (
        "outputs/metrics/results.json",
        "outputs/metrics/shift_safety_results.json",
        "outputs/metrics/robustness_results.json",
        "outputs/results.json",
    )
    records: dict[str, Any] = {}
    for relative in tabular_semantic:
        records[relative] = compare_csv(reference / relative, candidate / relative)
    for relative in json_semantic:
        expected = semantic_hash(normalize_numbers(scrub_volatile(load(reference / relative))))
        actual = semantic_hash(normalize_numbers(scrub_volatile(load(candidate / relative))))
        records[relative] = {
            "comparison": "exact_structure_floats_rounded_12dp",
            "expected": expected,
            "actual": actual,
            "pass": expected == actual,
        }
    for relative in semantic:
        expected = semantic_hash(normalize_numbers(scientific_payload(relative, reference)))
        actual = semantic_hash(normalize_numbers(scientific_payload(relative, candidate)))
        records[relative] = {
            "comparison": "explicit_scientific_semantic_hash",
            "excluded_fields": (
                "timestamps, commit metadata, gate/evidence state, runtime timings, "
                "serialized model hashes"
            ),
            "expected": expected,
            "actual": actual,
            "pass": expected == actual,
        }

    reference_figures = load(reference / "outputs/figures/figure_manifest.json")
    candidate_figures = load(candidate / "outputs/figures/figure_manifest.json")
    expected_names = sorted(reference_figures["figures"])
    actual_names = sorted(candidate_figures["figures"])
    figure_checks: dict[str, Any] = {}
    for name in sorted(set(expected_names) & set(actual_names)):
        expected_pixels = mpimg.imread(reference / "outputs" / "figures" / name)
        actual_pixels = mpimg.imread(candidate / "outputs" / "figures" / name)
        expected_hash = hashlib.sha256(expected_pixels.tobytes()).hexdigest()
        actual_hash = hashlib.sha256(actual_pixels.tobytes()).hexdigest()
        figure_checks[name] = {
            "shape_equal": expected_pixels.shape == actual_pixels.shape,
            "pixel_sha256_expected": expected_hash,
            "pixel_sha256_actual": actual_hash,
            "pass": (
                expected_pixels.shape == actual_pixels.shape
                and expected_hash == actual_hash
            ),
        }
    figures_pass = (
        expected_names == actual_names
        and len(figure_checks) == len(expected_names)
        and all(item["pass"] for item in figure_checks.values())
    )
    records["outputs/figures/figure_manifest.json"] = {
        "comparison": "exact_filenames_dimensions_and_decoded_pixels",
        "expected_names": expected_names,
        "actual_names": actual_names,
        "figures": figure_checks,
        "pass": figures_pass,
    }
    return {
        "pass": all(record["pass"] for record in records.values()),
        "artifacts": records,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference", type=Path)
    parser.add_argument("candidate", type=Path)
    args = parser.parse_args()
    result = compare(args.reference.resolve(), args.candidate.resolve())
    print(json.dumps(result, indent=2))
    if not result["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
