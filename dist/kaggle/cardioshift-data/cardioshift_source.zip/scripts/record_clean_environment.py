"""Record the isolated-environment verification without overclaiming G4."""

from __future__ import annotations

import json
import platform
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
import numpy
import pandas
import pytest
import scipy
import sklearn
import yaml

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "evidence" / "g4" / "local_clean_environment.json"


def git_head() -> str:
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        text=True,
    ).strip()


def run(command: list[str]) -> dict[str, object]:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        capture_output=True,
    )
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout_tail": completed.stdout[-4000:],
        "stderr_tail": completed.stderr[-4000:],
    }


def main() -> None:
    commands = [
        run([sys.executable, "scripts/gate_status.py"]),
        run([sys.executable, "scripts/verify_gate_g1.py"]),
        run([sys.executable, "scripts/verify_gate_g2.py", "--no-write"]),
        run([sys.executable, "scripts/verify_shift_safety.py", "--no-write"]),
        run([sys.executable, "scripts/verify_robustness.py"]),
        run([sys.executable, "scripts/verify_gate_g3.py"]),
        run([sys.executable, "scripts/verify_coder.py"]),
        run([sys.executable, "-m", "pytest", "-q"]),
    ]
    if any(item["returncode"] != 0 for item in commands):
        raise RuntimeError("isolated environment verification failed")
    pytest_output = "\n".join(
        str(commands[-1][field]) for field in ("stdout_tail", "stderr_tail")
    )
    counts = {
        name: sum(int(value) for value in re.findall(rf"(\d+) {name}", pytest_output))
        for name in ("passed", "skipped", "failed")
    }
    counts["subtests"] = sum(
        int(value) for value in re.findall(r"(\d+) subtests? passed", pytest_output)
    )
    report = {
        "status": "partial",
        "verified_at_utc": datetime.now(timezone.utc).isoformat(),
        "interpreter": sys.executable,
        "schema_version": "2.0",
        "python": platform.python_version(),
        "platform": platform.platform(),
        "verified_head": git_head(),
        "pytest_counts": counts,
        "packages": {
            "numpy": numpy.__version__,
            "pandas": pandas.__version__,
            "scikit-learn": sklearn.__version__,
            "scipy": scipy.__version__,
            "matplotlib": matplotlib.__version__,
            "PyYAML": yaml.__version__,
            "pytest": pytest.__version__,
        },
        "commands": commands,
        "passed": [
            "fresh virtual environment created",
            "requirements.lock installed",
            "G1 verifier",
            "G2 verifier",
            "E6/E7 verifier",
            "offline Notebook execution evidence and G3 verifier",
            "Coder static verifier",
            "E3/E5 verifier",
            "pytest suite",
            "evidence-driven gate status",
        ],
        "still_pending": [
            "real Coder control-plane runtime verification",
            "Kaggle public Notebook Run All",
            "logged-out public Notebook and Demo probes",
        ]
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(OUTPUT)


if __name__ == "__main__":
    main()

