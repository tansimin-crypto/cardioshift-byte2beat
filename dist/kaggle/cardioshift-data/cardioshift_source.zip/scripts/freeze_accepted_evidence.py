"""Freeze hashes for accepted E1-E5 artifacts before submission closure work."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "evidence" / "frozen_e1_e5.json"
FROZEN_PATHS = [
    "outputs/metrics/results.json",
    "outputs/metrics/shift_safety_results.json",
    "outputs/predictions/loho_predictions.csv",
    "outputs/predictions/random_split_predictions.csv",
    "outputs/predictions/safety_loho_predictions.csv",
    "outputs/audit/loho_training_ledgers.json",
    "evidence/g2/verification.json",
    "evidence/e3_e5/verification.json",
]


def git_blob(relative: str, revision: str) -> bytes:
    return subprocess.check_output(
        ["git", "show", f"{revision}:{relative}"],
        cwd=ROOT,
    )


def canonical_bytes(relative: str, content: bytes) -> bytes:
    path = Path(relative)
    if path.name == "Dockerfile" or path.suffix.lower() in {
        ".json",
        ".csv",
        ".md",
        ".py",
        ".yaml",
        ".yml",
        ".tf",
        ".sh",
        ".ipynb",
    }:
        content = content.replace(b"\r\r\n", b"\n").replace(b"\r\n", b"\n")
    return content


def sha256_bytes(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()


def artifact_record(relative: str, accepted_commit: str) -> dict[str, object]:
    canonical_blob = canonical_bytes(relative, git_blob(relative, accepted_commit))
    checkout = (ROOT / relative).read_bytes()
    return {
        "canonical_source": "git blob at accepted_commit (LF-normalized)",
        "bytes": len(canonical_blob),
        "sha256": sha256_bytes(canonical_blob),
        "checkout_sha256": sha256_bytes(checkout),
        "checkout_eol_may_differ": True,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--accepted-commit",
        required=True,
        help="Full 40-character commit SHA containing the accepted E1-E5 artifacts.",
    )
    return parser.parse_args()


def main() -> None:
    accepted_commit = parse_args().accepted_commit
    if len(accepted_commit) != 40 or any(
        character not in "0123456789abcdefABCDEF" for character in accepted_commit
    ):
        raise ValueError("--accepted-commit must be a full 40-character Git SHA")
    missing = [relative for relative in FROZEN_PATHS if not (ROOT / relative).exists()]
    if missing:
        raise FileNotFoundError(missing)
    report = {
        "schema_version": "2.0",
        "accepted_commit": accepted_commit,
        "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
        "artifacts": {
            relative: artifact_record(relative, accepted_commit)
            for relative in FROZEN_PATHS
        },
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(OUTPUT)


if __name__ == "__main__":
    main()

