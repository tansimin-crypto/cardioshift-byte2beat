CardioShift source code is licensed under the MIT License in LICENSE.
Bundled UCI data is separately licensed under CC BY 4.0.
